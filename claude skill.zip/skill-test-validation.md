# Stereo 3D Shader Hacking Skill - Validation Tests

## Test Cases from Documentation

### Test 1: Masterotaku Light Fix (r1.w-convergence*0.07)
**Question:** "Tengo luces que se mueven demasiado rápido cuando subo la convergencia. ¿Cómo hago que se queden en la posición correcta?"

**Expected Response from Skill:**
- Recognizes: Light element (r1.w contains depth)
- Suggests: `r1.x -= separation * (r1.w - convergence * 0.07)`
- Explains: The 0.07 multiplier slows down light movement relative to convergence
- Note: Multiplier is empirically determined; typical range 0.07-0.9

**✓ Skill covers:** Masterotaku formula section, empirical scaling explanation

---

### Test 2: Subnautica Sun Light (after matrix)
**Question:** "El sol en Subnautica aparece al mismo nivel que otros objetos. Aplicar la corrección a la matriz del mundo no funciona. ¿Dónde debería aplicar la corrección?"

**Expected Response from Skill:**
- Recognizes: Post-matrix correction needed (sun light rendered in screen space)
- Suggests: `r0.x -= stereo.x * r0.w * 0.9` (after matrix application)
- Explains: Sun uses clip-space w as depth; corrects per-pixel after projection
- Reference: Subnautica example with matrix chain

**✓ Skill covers:** Subnautica section, correction placement guide

---

### Test 3: Render Target Size Filtering
**Question:** "Algunos elementos HUD se dibujan en un buffer offscreen. ¿Cómo sé cuándo están en pantalla vs offscreen?"

**Expected Response from Skill:**
- Recognizes: HUD elements may be in offscreen buffers
- Suggests: Pass RT dimensions via IniParams (x1=rt_width, y1=rt_height, z1=res_width, w1=res_height)
- In shader: Compare RT dimensions with resolution to detect screen-drawn vs offscreen
- Example code provided

**✓ Skill covers:** HUD render target filtering pattern

---

### Test 4: Texture Filter Index
**Question:** "Tengo varias texturas y necesito aplicar la corrección solo a la crosshair. ¿Cómo aíslo una sola?"

**Expected Response from Skill:**
- Recognizes: Need selective shader application via texture hash
- Suggests: Use filter_index in TextureOverride + IniParams.Load to gate correction
- Example: `if (tex_filter.x == 2) { o0.x += stereo.x * 0.9; }`
- Pattern: TextureOverride with filter_index, check in shader via IniParams

**✓ Skill covers:** Texture filtering pattern, conditional application

---

### Test 5: Inverse Matrix for Decals
**Question:** "Los decals están proyectados en space de clip. Para aplicar stereo tengo que convertir a world, corregir, y re-proyectar. ¿Cómo hago eso automáticamente?"

**Expected Response from Skill:**
- Recognizes: Need inverse matrix technique
- Suggests: Use compute shader to pre-calculate inverse(ViewProjection)
- In PS: Unproject via inverse matrix, apply stereo, reproject
- Pattern: Custom shader resource + ResourceInputDecals + cs-cb0/cs-u0

**✓ Skill covers:** Inverse matrix technique section with CS setup

---

### Test 6: ShaderRegex Decal Pattern
**Question:** "Muchos shaders tienen el mismo patrón de proyección de decals. ¿Puedo fijar todos a la vez sin editar cada uno?"

**Expected Response from Skill:**
- Recognizes: ShaderRegex pattern matching
- Suggests: Define pattern to match decal projection sequence
- Automatically applies stereo correction to all matching shaders
- Example: Regex matching UV transformation + texture sampling + matrix projection

**✓ Skill covers:** ShaderRegex decal patterns section

---

## Validation Criteria

✅ **Pattern Recognition:** Skill identifies element type from context (light, HUD, decal, sun, etc.)
✅ **Formula Suggestion:** Provides appropriate formula + multiplier context
✅ **Placement Advice:** Explains WHERE in shader to apply correction (before/after matrix, view vs proj space)
✅ **Empirical Context:** Notes when multipliers are trial-and-error tuned
✅ **Tool-specific Syntax:** Provides 3Dmigoto ini syntax + HLSL/asm code
✅ **Real-world Examples:** References actual games (Subnautica, Kingdom Come, Forever Skies, ADR1FT)
✅ **Advanced Techniques:** Covers inverse matrices, regex, filter_index, render target filtering
