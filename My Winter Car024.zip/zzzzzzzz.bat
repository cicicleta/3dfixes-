@echo off
rd /s /q "ShaderCache"
rd /s /q "ShaderCacheDM"
rd /s /q "ShaderFixesDM"