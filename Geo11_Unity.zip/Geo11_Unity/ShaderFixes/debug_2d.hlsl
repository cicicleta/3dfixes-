Texture1D<float4> IniParams : register(t120);



struct vs2ps {
	float4 pos : SV_Position0;
	float2 uv : TEXCOORD1;
};

#ifdef VERTEX_SHADER
void main(
		out vs2ps output,
		uint vertex : SV_VertexID)
{
	// Not using vertex buffers so manufacture our own coordinates.
	switch(vertex) {
		case 0:
			output.pos.xy = float2(-1, -1);
			break;
		case 1:
			output.pos.xy = float2(-1, 1);
			break;
		case 2:
			output.pos.xy = float2(1, -1);
			break;
		case 3:
			output.pos.xy = float2(1, 1);
			break;
		default:
			output.pos.xy = 0;
			break;
	};
	output.pos.zw = float2(0, 1);
	output.uv = output.pos.xy * float2(0.5,-0.5) + 0.5;
}
#endif

#ifdef PIXEL_SHADER
Texture2D<float4> tex : register(t100);


void main(vs2ps input, out float4 result : SV_Target0)
{
	
	float4 debug2D = IniParams.Load(int2(70,0));
	
	uint width, height;
	tex.GetDimensions(width, height);
	if (!width || !height)
		discard;

	if (debug2D.y)
		input.uv.y = 1 - input.uv.y;

	result = tex.Load(int3(input.uv.xy * float2(width, height), 0)) * debug2D.x;
	if (debug2D.z == 1)
		result = result.x;
	else if (debug2D.z == 2)
		result = result.y;
	else if (debug2D.z == 3)
		result = result.z;
	else if (debug2D.z == 4)
		result = result.w;

	result = pow(abs(result), debug2D.w);
}
#endif
